###
### MODULE: caribouMovement
###
### DESCRIPTION: simulate caribou movement via correlated random walk
###               - requires a RasterStack object whose name is specified
###                 by `simGlobals(sim)$.stackName`, containing a RasterLayer
###                 named `habitatQuality`
###

### load any required packages
### (use `loadPackages`, or `library` directly)
pkgs <- list("SpaDES", "grid", "raster", "sp")
loadPackages(pkgs)
rm(pkgs)

### event functions
doEvent.caribouMovementLcc <- function(sim, eventTime, eventType, debug=FALSE) {
  if (eventType=="init") {
    ### check for module dependencies:
    ### (use NULL if no dependencies exist)
    depends <- NULL

    ### check for object dependencies:
    ### (use `checkObject` or similar)
    checkObject("vegMap")

    # if a required module isn't loaded yet,
    # reschedule this module init for later
    if (reloadModuleLater(sim, depends)) {
      sim <- scheduleEvent(sim, simCurrentTime(sim), "caribouMovementLcc", "init")
    } else  {
      # do stuff for this event
      sim <- caribouMovementInit(sim)

      # schedule the next event
      sim <- scheduleEvent(sim, simParams(sim)$caribouMovementLcc$startTime, "caribouMovementLcc", "move")
      sim <- scheduleEvent(sim, simParams(sim)$caribouMovementLcc$.plotInitialTime, "caribouMovementLcc", "plot.init")
      sim <- scheduleEvent(sim, simParams(sim)$caribouMovementLcc$glmInitialTime, "caribouMovementLcc", "glm.init")
    }
  } else if (eventType=="move") {
    # do stuff for this event
    sim <- caribouMovementMove(sim)

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$moveInterval, "caribouMovementLcc", "move")
  } else if (eventType=="plot.init") {
    # do stuff for this event

    #This wipes out previous values of the caribou map with a white raster
    a = try(seekViewport("caribou"), silent = TRUE)
    if(!is(a, "try-error")) {
      grid.rect(unit(1, "npc"), unit(1, "npc"), draw = TRUE,
              width = unit(1, units = "npc"), height=unit(1, units="npc"),
              gp=gpar(fill="white", col="white"), just = c(1,1))
    }

    Plot(caribouRas, pch=19, size=0.1, zero.color = "white")

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$.plotInterval, "caribouMovementLcc", "plot")
  } else if (eventType=="plot") {
    # do stuff for this event
    Plot(caribouRas, pch=19, size=0.1, zero.color = "white")

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$.plotInterval, "caribouMovementLcc", "plot")
  } else if (eventType=="save") {
    # do stuff for this event
    saveFiles(sim)

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$.saveInterval, "caribouMovementLcc", "save")

  } else if (eventType=="glm.init") {

    # do stuff for this event
    glmPVals <- numeric(simStopTime(sim))
    glmCaribouFire <- glm(getValues(caribouRas)~getValues(FiresCumul))
    glmPVals[1] <- summary(glmCaribouFire)[[13]]["getValues(FiresCumul)",'Pr(>|t|)']
    glmPlot <- qplot((simParams(sim)$caribouMovementLcc$glmInitialTime):simCurrentTime(sim),
          glmPVals[simParams(sim)$caribouMovementLcc$glmInitialTime:simCurrentTime(sim)],
          xlab="Simulation Time", ylab="p value: caribou ~ Fire",
          xlim=c(simParams(sim)$caribouMovementLcc$glmInitialTime,simStopTime(sim)))
    glmPlot <- glmPlot +
      theme(axis.text.x = element_text(size=6, colour="black"),
          axis.text.y = element_text(size=6, colour="black"),
          axis.title.x = element_text(size=8, colour="black"),
          axis.title.y = element_text(size=8, colour="black"),
          legend.position="none")

    assign("glmPlot", glmPlot, envir=.GlobalEnv)
    assign("glmPVals", glmPVals, envir=.GlobalEnv)
    Plot(glmPlot)
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$glmInterval, "caribouMovementLcc", "glm.plot")
    # schedule the next event

  } else if (eventType=="glm.plot") {
    # do stuff for this event
    glmCaribouFire <- glm(getValues(caribouRas)~getValues(FiresCumul))
    glmPVals[round(simCurrentTime(sim))] <- summary(glmCaribouFire)[[13]]["getValues(FiresCumul)",'Pr(>|t|)']
    glmPlot <- qplot((simParams(sim)$caribouMovementLcc$glmInitialTime):simCurrentTime(sim),
                     glmPVals[simParams(sim)$caribouMovementLcc$glmInitialTime:simCurrentTime(sim)],
                     xlab="Simulation Time", ylab="p value: caribou ~ Fire",
                     xlim=c(simParams(sim)$caribouMovementLcc$glmInitialTime,simStopTime(sim)))
    glmPlot <- glmPlot +
      theme(axis.text.x = element_text(size=6, colour="black"),
            axis.text.y = element_text(size=6, colour="black"),
            axis.title.x = element_text(size=8, colour="black"),
            axis.title.y = element_text(size=8, colour="black"),
            legend.position="none")
    assign("glmPlot", glmPlot, envir=.GlobalEnv)
    assign("glmPVals", glmPVals, envir=.GlobalEnv)
    Plot(glmPlot)

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$caribouMovementLcc$glmInterval, "caribouMovementLcc", "glm.plot")

  } else {
    warning(paste("Undefined event type: \'",simEvents(sim)[1,"eventType",with=FALSE],
                  "\' in module \'", simEvents(sim)[1,"moduleName",with=FALSE],"\'",sep=""))
  }
  return(invisible(sim))
}

caribouMovementInit <- function(sim) {
  cellsFromXY <<- cellFromXY # the raster Package has a bug
  caribouRas <<- raster(extent(vegMap), ncol=ncol(vegMap), nrow=nrow(vegMap), vals=0)

  yrange <- c(ymin(vegMap), ymax(vegMap))
  xrange <- c(xmin(vegMap), xmax(vegMap))
#    best <- max(values(vegMap))
#    worst <- min(values(vegMap))
#    good <- Which(vegMap>0.8*best)
#
#   al <- agentLocation(good)    # good vegMap, from above
#   initialCoords <- probInit(vegMap, al)

  # initialize caribou agents
  N <- simParams(sim)$caribouMovementLcc$N
  IDs <- as.character(1:N)
  sex <- sample(c("female", "male"), N, replace=TRUE)
  age <- round(rnorm(N, mean=8, sd=3))
  x1 <- rep(0, N)
  y1 <- rep(0, N)
  starts <- cbind(x=runif(N, xrange[1],xrange[2]),
                  y=runif(N, yrange[1],yrange[2]))

  # create the caribou agent object
  caribou <<- SpatialPointsDataFrame(coords=starts,
                                     data=data.frame(x1, y1, sex, age))
  row.names(caribou) <- IDs # alternatively, add IDs as column in data.frame above
  caribouRas[caribou] <- caribouRas[caribou]+1
  assign("caribouRas", caribouRas, envir=.GlobalEnv)
  return(invisible(sim))
}

caribouMovementMove <- function(sim) {
  # crop any caribou that went off maps

  if(length(caribou)==0) stop("All agents are off map")

  # find out what pixels the individuals are on now
  ex <- ageMap[caribou]

  # step length is a function of current cell's habitat quality
  sl <- 20/log(ex+5)

  ln <- rlnorm(length(ex), sl, 0.02) # log normal step length
  sd <- 30 # could be specified globally in params

  caribou <- move("crw", caribou, stepLength=ln, stddev=sd, lonlat=FALSE)
  caribou <<- crop(caribou, vegMap)

  caribouRas[caribou] <- caribouRas[caribou] + 1
  setColors(caribouRas) <- c("#FFFFFF", rev(heat.colors(maxValue(caribouRas))))
  assign("caribouRas",caribouRas,envir=.GlobalEnv)

#     #rads <- sample(10:30, length(caribou), replace=TRUE)
#     #rings <- cir(caribou, radiuses=rads, vegMap, 1)
#     #points(rings$x, rings$y, col=rings$ids, pch=19, cex=0.1)
#

    return(invisible(sim))
}
