###
### MODULE: fireSpreadLcc
###
### DESCRIPTION: simulate fire ignition and spread on a landscape
###               - spread probability varies according to percent pine
###               - stats re: fire size collected immediately after each burn event
###

### load any required packages
### (use `loadPackages` or similar)
pkgs <- list("SpaDES", "raster", "RColorBrewer", "methods")
loadPackages(pkgs)
rm(pkgs)

### event functions
doEvent.fireSpreadLcc <- function(sim, eventTime, eventType, debug=FALSE) {
  if (eventType=="init") {
    ### check for module dependencies:
    ### (use NULL if no dependencies exist)
    depends <- NULL #"forestSuccession"

    ### check for object dependencies:
    ### (use `checkObject` or similar)
    checkObject(name="vegMap")

    if (!exists(simGlobals(sim)$burnStats, envir=.GlobalEnv)) {
      assign(simGlobals(sim)$burnStats, numeric(), envir=.GlobalEnv)
    } else {
      npix <- get(simGlobals(sim)$burnStats, envir=.GlobalEnv)
      stopifnot("numeric" %in% is(npix), "vector" %in% is(npix))
      if (length(npix)>0) {
        message(paste0("Object `", simGlobals(sim)$burnStats, "` already exists and will be appended."))
      }
    }

    # if a required module isn't loaded yet,
    # reschedule this module init for later
    if (reloadModuleLater(sim, depends)) {
      sim <- scheduleEvent(sim, simCurrentTime(sim), "fireSpreadLcc", "init")
    } else {
      # do stuff for this event
      sim <- fireSpreadLccInit(sim)


      # schedule the next event
      sim <- scheduleEvent(sim, simParams(sim)$fireSpreadLcc$startTime, "fireSpreadLcc", "burn")
      sim <- scheduleEvent(sim, simParams(sim)$fireSpreadLcc$.saveInterval, "fireSpreadLcc", "save")
      sim <- scheduleEvent(sim, simParams(sim)$fireSpreadLcc$.plotInitialTime, "fireSpreadLcc", "plot.init")
    }
  } else if (eventType=="burn") {
    # do stuff for this event
    sim <- fireSpreadLccBurn(sim)

    # schedule the next events
    sim <- scheduleEvent(sim, simCurrentTime(sim), "fireSpreadLcc", "stats") # do stats immediately following burn
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$fireSpreadLcc$returnInterval, "fireSpreadLcc", "burn")
  } else if (eventType=="stats") {
    # do stuff for this event
    sim <- fireSpreadLccStats(sim)

    # schedule the next event
    ## stats scheduling done by burn event
  } else if (eventType=="plot.init") {
    # do stuff for this event
    Plot(FiresCumul,zero.color = "white")
    #maps <- get(simGlobals(sim)$.stackName, envir=.GlobalEnv)
    #setColors(maps) <- list(DEM=terrain.colors(100),
    #                            forestAge=brewer.pal(9,"BuGn"),
    #                            forestCover=brewer.pal(8,"BrBG"),
    #                            habitatQuality=brewer.pal(8,"Spectral"),
    #                            percentPine=brewer.pal(9,"Greens"),
    #                            Fires=c("#FFFFFF", rev(heat.colors(9)))
    #                        )
#    Plot(Fires, legendRange=c(0,qpois(0.95,simParams(sim)$fireSpreadLcc$nFires)))
    #assign(simGlobals(sim)$.stackName, maps, envir=.GlobalEnv)

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$fireSpreadLcc$.plotInterval, "fireSpreadLcc", "plot")
  } else if (eventType=="plot") {
    # do stuff for this event
    Plot(FiresCumul, zero.color = "white")
    FireSizeDistribution <- qplot(main = "", nPixelsBurned*6.25, xlab="Hectares")
    FireSizeDistribution <- FireSizeDistribution +
      theme(axis.text.x = element_text(size=6, angle = 45, hjust = 1, colour="black"),
            axis.text.y = element_text(size=6, colour="black"),
            axis.title.x = element_text(size=8, colour="black"),
            axis.title.y = element_text(size=8, colour="black"))
    assign("FireSizeDistribution", FireSizeDistribution, envir=.GlobalEnv)
    Plot(FireSizeDistribution)
    #dev(6); hist(nPixelsBurned*6.25, xlab="Hectares",
    #             main=paste0("Hectares burned by year ",simCurrentTime(sim)));
    #dev(dev.default)


    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$fireSpreadLcc$.plotInterval, "fireSpreadLcc", "plot")
  } else if (eventType=="save") {
    # do stuff for this event
    saveFiles(sim)

    # schedule the next event
    sim <- scheduleEvent(sim, simCurrentTime(sim) + simParams(sim)$fireSpreadLcc$.saveInterval, "fireSpreadLcc", "save")
  } else {
    warning(paste("Undefined event type: \'", simEvents(sim)[1, "eventType", with=FALSE],
                  "\' in module \'", simEvents(sim)[1, "moduleName", with=FALSE],"\'", sep=""))
  }
  return(invisible(sim))
}

fireSpreadLccInit <- function(sim) {
  #landscapes <- get(simGlobals(sim)$.stackName, envir=.GlobalEnv)


  ### create burn map that tracks fire locations over time
  Fires <- raster(extent(vegMap), ncol=ncol(vegMap),
                  nrow=nrow(vegMap), vals=0)

  setColors(Fires,n=simParams(sim)$fireSpreadLcc$nFires+1) <-
    c("#FFFFFF", rev(heat.colors(simParams(sim)$fireSpreadLcc$nFires)))
  #Fires <<- setValues(Fires, 0)

  # add Fires map to global$.stackName stack
  #  assign(simGlobals(sim)$.stackName, addLayer(landscapes,Fires), envir=.GlobalEnv)
  assign("Fires", Fires, envir=.GlobalEnv)

  FiresCumul <<- Fires#raster(extent(vegMap), ncol=ncol(vegMap),
  #                     nrow=nrow(vegMap), vals=0)

  #assign("Fires", Fires, envir=.GlobalEnv)

  # last thing to do is add module name to the loaded list
  simModulesLoaded(sim) <- append(simModulesLoaded(sim), "fireSpreadLcc")

  return(invisible(sim))
}


fireSpreadLccBurn <- function(sim) {
 # landscapes <- get(simGlobals(sim)$.stackName, envir=.GlobalEnv)

  fireSpreadProb <<- reclassify(x=vegMap,
                                rcl=cbind(1:11,
                                          c(0.225,0.225,0.21,0.15,0.15,0.18,0.1,0.1,0,0,0)*
                                          simParams(sim)$fireSpreadLcc$drought))
  nFires <<- rpois(1,simParams(sim)$fireSpreadLcc$nFires*simParams(sim)$fireSpreadLcc$drought)
  Fires <- spread(fireSpreadProb,
                   loci=as.integer(sample(1:ncell(fireSpreadProb), nFires)),
                   spreadProb=fireSpreadProb,
                   persistance=simParams(sim)$fireSpreadLcc$persistprob,
                   mask=NULL,
                   maxSize=1e8,
                   directions=8,
                   iterations=simParams(sim)$fireSpreadLcc$its,
                   plot.it=FALSE,
                   mapID=TRUE)
  names(Fires) <- "Fires"
  setColors(Fires,n=nFires+1) <- c("#FFFFFF", rev(heat.colors(nFires)))
  #  landscapes$Fires <- Fires

  FiresCumul[] <- FiresCumul[] + (Fires[]>0)
  setColors(FiresCumul) <- c(colorRampPalette(c("orange", "darkred"))(maxValue(FiresCumul)+1))
  assign("Fires", Fires, envir=.GlobalEnv)
  assign("FiresCumul", FiresCumul, envir=.GlobalEnv)

  return(invisible(sim))
}

fireSpreadLccStats <- function(sim) {
  npix <- get(simGlobals(sim)$burnStats, envir=.GlobalEnv)

  #landscapes <- get(simGlobals(sim)$.stackName, envir=.GlobalEnv)

  assign("nPixelsBurned", c(npix, length(which(values(Fires)>0))), envir=.GlobalEnv)

  return(invisible(sim))
}

