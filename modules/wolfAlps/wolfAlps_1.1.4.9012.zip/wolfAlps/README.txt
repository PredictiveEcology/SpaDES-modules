Please see the html site that shows how to use this model:
https://htmlpreview.github.io/?https://github.com/PredictiveEcology/SpaDES-modules/blob/master/modules/wolfAlps/wolfAlps.html

Any other details that a user may need to know, like where to get more information,
where to download data, etc.